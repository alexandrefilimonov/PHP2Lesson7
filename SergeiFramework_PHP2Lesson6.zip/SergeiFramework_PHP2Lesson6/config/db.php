<?php
	define('DRIVER','mysql');
	define('SERVER', 'localhost');
	define('USERNAME', 'root');
	define('PASSWORD', 'DeltaDental!');
	define('DB', 'world');
?>