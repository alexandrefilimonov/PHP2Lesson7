<h3><?php if(isset($text)){echo $text;}?></h3>
<br>
<form method="post">
	<?php if(isset($message_text)){echo $message_text;}?>		
	<?php if(isset($item_text)){echo $item_text;}?>			
</form>