<h3><?php if(isset($text)){echo $text;}?></h3>
<br>
<form method="post">
	<table border=0>
		<tr align="center">
			<td width=120>Номер букета:</td><td width=140>Изображение товара:</td><td width=200>Название:</td><td width=80>Цена:</td><td></td>
		</tr>	
		<?php if(isset($catalog_text)){echo $catalog_text;}?>			
	</table>
</form>