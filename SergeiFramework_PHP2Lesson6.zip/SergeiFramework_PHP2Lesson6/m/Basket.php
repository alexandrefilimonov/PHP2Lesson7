<?php
	include_once 'config/db.php';

	class Basket {
		
		public $user_id, $user_login, $user_name, $user_password;

		public function __construct () {
		}

		public function connecting () {
			return new PDO(DRIVER . ':host='. SERVER . ';dbname=' . DB, USERNAME, PASSWORD);
		}

		public function get ($user_id) {
			$connect = $this->connecting();
			$connection = mysqli_connect("localhost","root","DeltaDental!","world"); 
			//echo "SELECT COUNT(basket.id_good) AS num, basket.id_good, goods.name, basket.price FROM basket INNER JOIN goods ON basket.id_good=goods.id_good WHERE basket.id_user=".$user_id." AND basket.is_in_order=0 GROUP BY basket.id_good"; 
			return mysqli_query($connection, "SELECT COUNT(basket.id_good) AS num, basket.id_good, goods.name, basket.price FROM basket INNER JOIN goods ON basket.id_good=goods.id_good WHERE basket.id_user=".$user_id." AND basket.is_in_order=0 GROUP BY basket.id_good");
			//return $connect->query("SELECT * FROM goods"); /*->fetch_all(1); fetch(); MYSQLI_NUM*/
		}
		
		public function makeorder ($user_id, $sum) {
			$connect = $this->connecting();
			$connection = mysqli_connect("localhost","root","DeltaDental!","world"); 
			//It should be begin of trasaction here
			$connect->exec("UPDATE basket SET is_in_order=1 WHERE id_user=".$user_id." AND is_in_order=0");
			//echo "INSERT INTO `orders` (`id_user`, `amount`, `id_order_status`) VALUES (".$user_id.",'".$sum."',1)"; 
			$connect->exec("INSERT INTO `orders` (`id_user`, `amount`, `id_order_status`) VALUES (".$user_id.",'".$sum."',1)");
			return true;
			//It should be end of trasaction here
		}
		
		public function getqty () {
			$connect = $this->connecting();
			return $connect->query("SELECT COUNT(*) FROM world.goods WHERE status=1")->fetch();
		}
		public function add_to_basket($id_good, $user_id) {
			$connect = $this->connecting();
			$good = $connect->query("SELECT * FROM goods WHERE id_good = '" . $id_good . "'")->fetch();
			if ($good) {
				$price = $good['price'];
				//echo '1 par - это '.$price;
				//echo "INSERT INTO basket (`id_user`, `id_good`, `price`, `is_in_order`, `id_order`) VALUES (" . $user_id . "," . $id_good . ", '" . $price . "',0,0)"; 
				$connect->exec("INSERT INTO basket (`id_user`, `id_good`, `price`, `is_in_order`, `id_order`) VALUES (" . $user_id . "," . $id_good . ", '" . $price . "',0,0)");
				return true;
			} else {
				return false;
			}
		}
	}
?>